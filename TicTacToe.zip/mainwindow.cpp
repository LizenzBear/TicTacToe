#include "mainwindow.h"

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
{
    setupUi(this);

    QGridLayout *gridLayout = new QGridLayout;

    for (int row = 0; row < 3; ++row) {
        for (int col = 0; col < 3; ++col) {
            buttons[row][col] = new QPushButton("");
            buttons[row][col]->setFixedSize(100, 100);
            gridLayout->addWidget(buttons[row][col], row, col);

            connect(buttons[row][col], &QPushButton::clicked, [=]() {
                handleButtonClick(row, col);
            });

            board[row][col] = ' ';
        }
    }

    QWidget *centralWidget = new QWidget(this);
    centralWidget->setLayout(gridLayout);
    setCentralWidget(centralWidget);
    QMessageBox::information(this, "Tutorial", "Player: X starts the game");
}

void MainWindow::handleButtonClick(int row, int col) {
    if (board[row][col] == ' ') {
        board[row][col] = currentPlayer;
        buttons[row][col]->setText(QString(currentPlayer));

        checkForWinner();

        currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
    }
}

void MainWindow::checkForWinner() {
    for (int i = 0; i < 3; ++i) {
        // Reihen und Spalten
        if ((board[i][0] == currentPlayer && board[i][1] == currentPlayer && board[i][2] == currentPlayer) ||
            (board[0][i] == currentPlayer && board[1][i] == currentPlayer && board[2][i] == currentPlayer)) {
            QMessageBox::information(this, "Game Over", QString("%1 wins!").arg(currentPlayer));
            resetGame();
            return;
        }
    }

    // Diagonalen
    if ((board[0][0] == currentPlayer && board[1][1] == currentPlayer && board[2][2] == currentPlayer) ||
        (board[0][2] == currentPlayer && board[1][1] == currentPlayer && board[2][0] == currentPlayer)) {
        QMessageBox::information(this, "Game Over", QString("%1 wins!").arg(currentPlayer));
        resetGame();
        return;
    }

    // Unentschieden
    bool draw = true;
    for (int row = 0; row < 3; ++row) {
        for (int col = 0; col < 3; ++col) {
            if (board[row][col] == ' ') {
                draw = false;
                break; // falls game noch nicht durch Reihe / Spalte / Diagonale entschieden ist und alles belegt ist = draw
            }
        }
    }

    if (draw) {
        QMessageBox::information(this, "Game Over", "It's a draw!");
        resetGame();
    }
}

void MainWindow::resetGame() {
    currentPlayer = 'O';
    for (int row = 0; row < 3; ++row) {
        for (int col = 0; col < 3; ++col) {
            board[row][col] = ' ';
            buttons[row][col]->setText("");
        }
    }
}

MainWindow::~MainWindow() {
    delete ui;
}
